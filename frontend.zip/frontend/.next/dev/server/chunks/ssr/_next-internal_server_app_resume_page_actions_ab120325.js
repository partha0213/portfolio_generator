module.exports = [
"[project]/.next-internal/server/app/resume/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_resume_page_actions_ab120325.js.map