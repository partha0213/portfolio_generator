module.exports = [
"[project]/.next-internal/server/app/editor/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_editor_page_actions_182e8140.js.map