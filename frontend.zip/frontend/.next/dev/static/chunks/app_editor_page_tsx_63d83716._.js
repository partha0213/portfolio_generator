(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e54dbc01._.js",
  "static/chunks/node_modules_94347eb5._.js"
],
    source: "dynamic"
});
