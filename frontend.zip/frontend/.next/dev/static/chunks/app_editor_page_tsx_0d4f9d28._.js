(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_jszip_lib_index_f782ac2d.js",
  "static/chunks/_8fd991ef._.js",
  "static/chunks/node_modules_59fd05f7._.js"
],
    source: "dynamic"
});
