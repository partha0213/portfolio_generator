'use client';

import { useState, useRef, useEffect } from 'react';
import { sendChatMessage, getChatHistory, initChat } from '@/lib/api';

interface ChatPanelProps {
    sessionId: string;
    resumeData: any;
    currentFiles: Record<string, string>;
    onFilesChange: (files: Record<string, string>) => void;
}

interface ChatMessage {
    role: string;
    content: string;
    filesModified?: string[];
}

export default function ChatPanel({ sessionId, resumeData, currentFiles, onFilesChange }: ChatPanelProps) {
    const [messages, setMessages] = useState<ChatMessage[]>([
        {
            role: 'assistant',
            content: "Hi! I'm Portfolio.AI. Tell me about yourself, your skills, and the projects you want to showcase, and I'll build a website for you."
        }
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [historyLoaded, setHistoryLoaded] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Load chat history on mount
    useEffect(() => {
        const loadChatHistory = async () => {
            try {
                // Initialize chat (creates welcome message if needed)
                await initChat(sessionId);
                
                const response = await getChatHistory(sessionId);
                if (response.success && response.messages && response.messages.length > 0) {
                    // Format messages to match ChatMessage interface
                    const formattedMessages = response.messages.map((msg: any) => ({
                        role: msg.role,
                        content: msg.message
                    }));
                    
                    setMessages(formattedMessages);
                }
            } catch (error) {
                console.warn('Could not load chat history:', error);
                // Don't fail - just use default initial message
            } finally {
                setHistoryLoaded(true);
            }
        };

        if (sessionId && !historyLoaded) {
            loadChatHistory();
        }
    }, [sessionId, historyLoaded]);

    // Scroll to bottom when messages change
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim() || loading) return;

        const userMessage: ChatMessage = { role: 'user', content: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setLoading(true);

        try {
            // Use the basic chat endpoint
            const response = await sendChatMessage(
                [...messages, userMessage],
                sessionId,
                currentFiles
            );

            // Check if AI modified any files
            const filesModified = response.file_changes ? Object.keys(response.file_changes) : undefined;

            // Apply file changes
            if (response.file_changes) {
                const updatedFiles = { ...currentFiles };
                Object.entries(response.file_changes).forEach(([filename, content]) => {
                    updatedFiles[filename] = content as string;
                });
                onFilesChange(updatedFiles);
            }

            setMessages(prev => [...prev, {
                role: 'assistant',
                content: response.response,
                filesModified
            }]);
        } catch (error) {
            console.error('Chat error:', error);
            setMessages(prev => [...prev, {
                role: 'assistant',
                content: '❌ Sorry, I encountered an error. Please try again.'
            }]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="h-full flex flex-col">
            {/* Messages area */}
            <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 sm:space-y-4">
                {messages.map((msg, idx) => (
                    <div
                        key={idx}
                        className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                        <div
                            className={`max-w-[85%] sm:max-w-[80%] rounded-2xl px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base ${msg.role === 'user'
                                    ? 'bg-[#2563eb] text-white'
                                    : 'bg-[#1e293b] text-gray-200 border border-gray-700/50'
                                }`}
                        >
                            <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>

                            {/* Files modified indicator */}
                            {msg.filesModified && msg.filesModified.length > 0 && (
                                <div className="mt-2 pt-2 border-t border-gray-600/50">
                                    <p className="text-xs text-gray-400 font-medium mb-1">✏️ Modified files:</p>
                                    {msg.filesModified.map((file, i) => (
                                        <p key={i} className="text-xs text-green-400">• {file}</p>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                ))}

                {loading && (
                    <div className="flex justify-start">
                        <div className="bg-[#1e293b] border border-gray-700/50 rounded-2xl px-3 sm:px-4 py-2 sm:py-3">
                            <div className="flex gap-1.5">
                                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                            </div>
                        </div>
                    </div>
                )}

                <div ref={messagesEndRef} />
            </div>

            {/* Input area */}
            <div className="p-3 sm:p-4 border-t border-gray-800/50">
                <div className="flex gap-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="e.g., 'I'm a UX designer...'"
                        className="flex-1 bg-[#1e293b] text-white text-xs sm:text-sm px-3 sm:px-4 py-2 sm:py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder-gray-500 border border-gray-700/50"
                        disabled={loading}
                    />
                    <button
                        onClick={handleSend}
                        disabled={loading || !input.trim()}
                        className="px-3 sm:px-4 py-2 sm:py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center min-w-[44px] sm:min-w-[48px]"
                    >
                        <svg className="w-4 sm:w-5 h-4 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    );
}
