"""
Schema-Validated Portfolio Generator (Gemini with OpenAI Fallback)
"""

import os
import json
import time
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import asyncio

from dotenv import load_dotenv
import google.generativeai as genai
from google.api_core import exceptions
from openai import OpenAI, AsyncOpenAI

load_dotenv()

class LovableStyleGenerator:
    """
    Schema-validated portfolio generator.
    Primary: Gemini 2.0 Flash
    Fallback: OpenAI GPT-4o
    """
    
    # Portfolio Config Schema (Python dict format for JSON schema)
    PORTFOLIO_SCHEMA = {
        "type": "object",
        "properties": {
            "fullName": {"type": "string"},
            "role": {"type": "string"},
            "bio": {"type": "string"},
            "skills": {
                "type": "array",
                "items": {"type": "string"}
            },
            "projects": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "description": {"type": "string"},
                        "technologies": {
                            "type": "array",
                            "items": {"type": "string"}
                        },
                        "imageUrl": {"type": "string"},
                        "link": {"type": "string"}
                    }
                }
            },
            "socials": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "platform": {
                            "type": "string",
                            "enum": ["GitHub", "LinkedIn", "Twitter", "Email", "Portfolio"]
                        },
                        "url": {"type": "string"}
                    }
                }
            },
            "style": {
                "type": "object",
                "properties": {
                    "layout": {
                        "type": "string",
                        "enum": ["minimal", "modern", "bold"]
                    },
                    "fontHeading": {"type": "string"},
                    "fontBody": {"type": "string"},
                    "colors": {
                        "type": "object",
                        "properties": {
                            "primary": {"type": "string"},
                            "secondary": {"type": "string"},
                            "background": {"type": "string"},
                            "text": {"type": "string"},
                            "cardBackground": {"type": "string"}
                        }
                    }
                }
            }
        },
        "required": ["fullName", "role", "bio", "skills", "projects", "style"]
    }
    
    SYSTEM_INSTRUCTION = """You are an expert web designer and portfolio generator AI.

Your task is to interpret user requests and generate a JSON configuration for a portfolio website.

DESIGN GUIDELINES:
- 'minimal': Clean, whitespace, simple typography, subtle colors
- 'modern': Card layouts, glassmorphism, vibrant accents, dark mode
- 'bold': Large typography, high contrast, strong colors

DEFAULTS:
- Choose color palette matching the layout style
- Use placeholder images from picsum.photos
- Ensure accessible color contrast
- Extract ALL relevant info from resume data

Return ONLY the PortfolioConfig JSON matching the schema."""
    
    def __init__(self):
        """Initialize Gemini and OpenAI."""
        # Gemini Init
        api_key = os.getenv("GEMINI_API_KEY")
        if api_key:
            genai.configure(api_key=api_key)
            self.model_name = "gemini-1.5-flash"
            print(f"✅ Gemini initialized: {self.model_name}")
        else:
            print("⚠️ GEMINI_API_KEY not found.")
            self.model_name = None

        # OpenAI Init (Fallback)
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        self.openai_client = None
        if self.openai_api_key:
            self.openai_client = AsyncOpenAI(api_key=self.openai_api_key)
            print("✅ OpenAI initialized for fallback")
        else:
            print("⚠️ OPENAI_API_KEY not found. Fallback unavailable.")
    
    async def generate_portfolio(
        self, 
        user_prompt: str, 
        resume_data: Dict,
        framework: str = "nextjs"
    ) -> Dict:
        """Generate portfolio using two-step process."""
        print("\n" + "="*70)
        print("🚀 PORTFOLIO GENERATION")
        print("="*70)
        print(f"📝 Prompt: {user_prompt[:80]}...")
        
        try:
            # Step 1: Generate Config
            print("\n📋 Step 1: Generating portfolio config...")
            config = await self._generate_config(user_prompt, resume_data)
            
            if not config:
                return {"success": False, "error": "Failed to generate config"}
            
            print(f"✅ Config generated: {config.get('fullName')}")
            
            # Step 2: Generate Code
            print(f"\n💻 Step 2: Generating {framework} code...")
            files = self._generate_code_from_config(config, framework)
            
            print(f"✅ Generated {len(files)} files")
            print("="*70 + "\n")
            
            return {
                "success": True,
                "files": files,
                "design_notes": {
                    "framework": framework,
                    "config": config
                },
                "error": None
            }
            
        except Exception as e:
            print(f"❌ Generation failed: {e}")
            import traceback
            traceback.print_exc()
            return {"success": False, "error": str(e)}

    async def _generate_config(self, user_prompt: str, resume_data: Dict) -> Optional[Dict]:
        """Generate config with Gemini, fallback to OpenAI."""
        
        # Prepare Prompt
        resume_summary = {
            "name": resume_data.get("name", ""),
            "title": resume_data.get("title", ""),
            "summary": resume_data.get("summary", "")[:300],
            "skills": resume_data.get("skills", [])[:20],
            "projects": resume_data.get("projects", [])[:6],
            "socials": resume_data.get("links", {}) # Resume parser returns 'links'
        }
        
        prompt = f"""Design Vision: {user_prompt}
Resume Data: {json.dumps(resume_summary, indent=2)}
Generate a complete portfolio configuration based on the schema."""

        # Try Gemini
        if self.model_name:
            try:
                model = genai.GenerativeModel(
                    model_name=self.model_name,
                    system_instruction=self.SYSTEM_INSTRUCTION,
                )
                
                response = await asyncio.to_thread(
                    model.generate_content,
                    prompt,
                    generation_config=genai.GenerationConfig(
                        temperature=0.7,
                        response_mime_type="application/json"
                    )
                )
                return json.loads(response.text)
            except Exception as e:
                print(f"⚠️ Gemini failed: {e}")
        
        # Fallback to OpenAI
        if self.openai_client:
            print("🔄 Switching to OpenAI fallback...")
            return await self._generate_config_openai(prompt)
            
        return None

    def _generate_code_from_config(self, config: Dict, framework: str) -> Dict[str, str]:
        if framework == "nextjs":
            return self._generate_nextjs_code(config)
        return self._generate_nextjs_code(config)

    def _generate_nextjs_code(self, config: Dict) -> Dict[str, str]:
        """Generate Next.js 15 project with inline SVG icons for browser compatibility."""
        
        style = config.get("style", {})
        colors = style.get("colors", {})
        
        # app/page.tsx with inline SVG icons
        page_tsx = f"""'use client';

export default function Portfolio() {{
  const fullName = {json.dumps(config.get('fullName'))};
  const role = {json.dumps(config.get('role'))};
  const bio = {json.dumps(config.get('bio'))};
  const skills = {json.dumps(config.get('skills', []))};
  const projects = {json.dumps(config.get('projects', []))};
  const socials = {json.dumps(config.get('socials', []))};

  // Inline SVG icons for browser compatibility
  const GithubIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/>
      <path d="M9 18c-4.51 2-5-2-7-2"/>
    </svg>
  );

  const LinkedinIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/>
      <rect x="2" y="9" width="4" height="12"/>
      <circle cx="4" cy="4" r="2"/>
    </svg>
  );

  const TwitterIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/>
    </svg>
  );

  const MailIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="4" width="20" height="16" rx="2"/>
      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
    </svg>
  );

  const ExternalLinkIcon = () => (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
      <polyline points="15 3 21 3 21 9"/>
      <line x1="10" y1="14" x2="21" y2="3"/>
    </svg>
  );

  const getSocialIcon = (platform) => {{
    const icons = {{
      'GitHub': <GithubIcon />,
      'LinkedIn': <LinkedinIcon />,
      'Twitter': <TwitterIcon />,
      'Email': <MailIcon />,
    }};
    return icons[platform] || <MailIcon />;
  }};

  return (
    <div className="min-h-screen" style={{{{ backgroundColor: '{colors.get('background', '#0a0a0a')}', color: '{colors.get('text', '#ffffff')}' }}}}>
      {{/* Header */}}
      <header className="px-6 py-20 max-w-6xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-bold mb-4">{{fullName}}</h1>
        <p className="text-xl md:text-2xl mb-6" style={{{{ color: '{colors.get('primary', '#3b82f6')}' }}}}>{{role}}</p>
        <p className="text-base md:text-lg opacity-75 max-w-2xl mb-8">{{bio}}</p>
        
        <div className="flex gap-4">
          {{socials.map((s, i) => (
            <a 
              key={{i}} 
              href={{s.url}} 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-3 rounded-full hover:scale-110 transition-transform" 
              style={{{{ backgroundColor: '{colors.get('cardBackground', '#1a1a1a')}' }}}}
              aria-label={{s.platform}}
            >
              {{getSocialIcon(s.platform)}}
            </a>
          ))}}
        </div>
      </header>

      {{/* Skills */}}
      <section className="px-6 py-12 max-w-6xl mx-auto">
        <h2 className="text-2xl md:text-3xl font-bold mb-8">Skills</h2>
        <div className="flex flex-wrap gap-3">
          {{skills.map((skill, i) => (
            <span 
              key={{i}} 
              className="px-4 py-2 rounded-lg border text-sm md:text-base" 
              style={{{{ 
                backgroundColor: '{colors.get('cardBackground', '#1a1a1a')}',
                borderColor: '{colors.get('primary', '#3b82f6')}40'
              }}}}
            >
              {{skill}}
            </span>
          ))}}
        </div>
      </section>

      {{/* Projects */}}
      <section className="px-6 py-12 max-w-6xl mx-auto">
        <h2 className="text-2xl md:text-3xl font-bold mb-12">Featured Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {{projects.map((project, i) => (
            <div 
              key={{i}} 
              className="rounded-xl overflow-hidden group hover:shadow-2xl transition-all" 
              style={{{{ backgroundColor: '{colors.get('cardBackground', '#1a1a1a')}' }}}}
            >
              <div className="relative overflow-hidden aspect-video">
                <img 
                  src={{project.imageUrl || `https://picsum.photos/800/600?random=${{i}}`}} 
                  alt={{project.title}} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                />
                {{project.link && (
                  <a 
                    href={{project.link}} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                    aria-label="View project"
                  >
                    <ExternalLinkIcon />
                  </a>
                )}}
              </div>
              <div className="p-6">
                <h3 className="text-lg md:text-xl font-bold mb-2">{{project.title}}</h3>
                <p className="text-sm opacity-70 mb-4 line-clamp-2">{{project.description}}</p>
                <div className="flex flex-wrap gap-2">
                  {{project.technologies.map((tech, j) => (
                    <span 
                      key={{j}} 
                      className="text-xs px-2 py-1 rounded" 
                      style={{{{ backgroundColor: '{colors.get('primary', '#3b82f6')}20' }}}}
                    >
                      {{tech}}
                    </span>
                  ))}}
                </div>
              </div>
            </div>
          ))}}
        </div>
      </section>

      <footer className="text-center py-12 opacity-40 text-sm">
        <p>© {{new Date().getFullYear()}} {{fullName}}. Built with AI.</p>
      </footer>
    </div>
  );
}}
"""
        
        # app/layout.tsx
        layout_tsx = f"""import type {{ Metadata }} from 'next';
import './globals.css';

export const metadata: Metadata = {{
  title: '{config.get('fullName')} - Portfolio',
  description: '{config.get('bio', '')[:100]}',
}};

export default function RootLayout({{
  children,
}}: {{
  children: React.ReactNode;
}}) {{
  return (
    <html lang="en">
      <body>{{children}}</body>
    </html>
  );
}}
"""
        
        # app/globals.css
        globals_css = f"""@tailwind base;
@tailwind components;
@tailwind utilities;

@import url('https://fonts.googleapis.com/css2?family={style.get('fontHeading', 'Inter').replace(' ', '+')}:wght@700&family={style.get('fontBody', 'Inter').replace(' ', '+')}:wght@400&display=swap');

body {{
  font-family: '{style.get('fontBody', 'Inter')}', sans-serif;
}}

h1, h2, h3, h4, h5, h6 {{
  font-family: '{style.get('fontHeading', 'Inter')}', sans-serif;
}}
"""
        
        # tailwind.config.ts
        tailwind_config = f"""import type {{ Config }} from 'tailwindcss';

const config: Config = {{
  content: [
    './pages/**/*.{{js,ts,jsx,tsx,mdx}}',
    './components/**/*.{{js,ts,jsx,tsx,mdx}}',
    './app/**/*.{{js,ts,jsx,tsx,mdx}}',
  ],
  theme: {{
    extend: {{
      colors: {{
        primary: '{colors.get('primary', '#3b82f6')}',
        secondary: '{colors.get('secondary', '#8b5cf6')}',
      }},
    }},
  }},
  plugins: [],

## Setup

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Customization

Edit the configuration in `app/page.tsx` to customize your portfolio.

## Deploy

Deploy easily to Vercel:

```bash
vercel
```
"""
        
        return {
            "app/page.tsx": page_tsx,
            "app/layout.tsx": layout_tsx,
            "app/globals.css": globals_css,
            "tailwind.config.ts": tailwind_config,
            "package.json": json.dumps(package_json, indent=2),
            "README.md": readme,
        }

    def validate_generated_code(self, files: Dict[str, str]) -> Tuple[bool, List[str]]:
        """
        Validate generated code files for common issues.
        Returns (is_valid, validation_errors)
        """
        errors = []
        
        # Check if required files exist
        required_files = ["app/page.tsx", "app/layout.tsx", "package.json"]
        for required_file in required_files:
            if required_file not in files:
                errors.append(f"Missing required file: {required_file}")
        
        # Validate package.json is valid JSON
        if "package.json" in files:
            try:
                json.loads(files["package.json"])
            except json.JSONDecodeError as e:
                errors.append(f"Invalid package.json: {str(e)}")
        
        # Validate TSX files contain JSX
        tsx_files = [f for f in files if f.endswith('.tsx')]
        for tsx_file in tsx_files:
            content = files[tsx_file]
            if '<' not in content or '>' not in content:
                errors.append(f"TSX file may be missing JSX: {tsx_file}")
        
        # Validate CSS files
        if "app/globals.css" in files:
            css_content = files["app/globals.css"]
            if "@tailwind" not in css_content:
                errors.append("globals.css missing Tailwind directives")
        
        is_valid = len(errors) == 0
        return is_valid, errors

    async def refine_portfolio(
        self, 
        refinement_request: str, 
        current_files: Dict[str, str],
        resume_data: Dict
    ) -> Dict:
        """
        Refine an existing portfolio based on user feedback.
        
        Args:
            refinement_request: User's refinement request/feedback
            current_files: Current portfolio files
            resume_data: Resume data for context
        
        Returns:
            Dict with success status, refined files, and errors
        """
        try:
            # Prepare refinement prompt
            refinement_prompt = f"""You are a portfolio refinement specialist.

User Feedback: {refinement_request}

Current Portfolio Structure:
{json.dumps({{k: len(v) for k, v in current_files.items()}}, indent=2)}

Resume Data (for context):
{json.dumps(resume_data, indent=2)[:500]}

Task: Refine the portfolio based on the user feedback. Return ONLY the refined files as a JSON object with filenames as keys.
Keep the same file structure and only modify the necessary files.

Return format: {{"file1.tsx": "content", "file2.css": "content", ...}}"""

            # Try Gemini first
            if self.model_name:
                try:
                    model = genai.GenerativeModel(self.model_name)
                    response = await asyncio.to_thread(
                        model.generate_content,
                        refinement_prompt,
                        generation_config=genai.GenerationConfig(
                            temperature=0.7,
                            response_mime_type="application/json"
                        )
                    )
                    refined_files = json.loads(response.text)
                    
                    # Merge with current files (only override changed files)
                    merged_files = {**current_files, **refined_files}
                    
                    print(f"✅ Refinement successful: Updated {len(refined_files)} files")
                    return {
                        "success": True,
                        "files": merged_files,
                        "error": None
                    }
                except Exception as e:
                    print(f"⚠️ Gemini refinement failed: {e}")
            
            # Fallback to OpenAI
            if self.openai_client:
                print("🔄 Switching to OpenAI for refinement...")
                try:
                    response = await self.openai_client.chat.completions.create(
                        model="gpt-4o",
                        messages=[
                            {"role": "user", "content": refinement_prompt}
                        ],
                        response_format={"type": "json_object"},
                        temperature=0.7
                    )
                    refined_files = json.loads(response.choices[0].message.content)
                    
                    # Merge with current files
                    merged_files = {**current_files, **refined_files}
                    
                    print(f"✅ OpenAI refinement successful: Updated {len(refined_files)} files")
                    return {
                        "success": True,
                        "files": merged_files,
                        "error": None
                    }
                except Exception as e:
                    print(f"❌ OpenAI refinement failed: {e}")
                    return {
                        "success": False,
                        "files": current_files,
                        "error": str(e)
                    }
            
            # If no LLM available, return current files unchanged
            print("⚠️ No LLM available for refinement")
            return {
                "success": False,
                "files": current_files,
                "error": "No AI service available for refinement"
            }
            
        except Exception as e:
            print(f"❌ Refinement error: {e}")
            import traceback
            traceback.print_exc()
            return {
                "success": False,
                "files": current_files,
                "error": str(e)
            }