"""
Portfolio Configuration Generator - Gemini-based service

Generates PortfolioConfig JSON matching frontend schema.
Uses inline SVG icons instead of lucide-react.
"""

import os
import json
import asyncio
from typing import Dict, Optional, Tuple
from datetime import datetime

from dotenv import load_dotenv
import google.generativeai as genai
from openai import AsyncOpenAI

load_dotenv()


class PortfolioConfigGenerator:
    """
    Generates portfolio configurations using Gemini 2.5 Flash.
    Fallback: OpenAI GPT-4o
    """

    # Schema matching frontend TypeScript types
    PORTFOLIO_SCHEMA = {
        "type": "object",
        "properties": {
            "reply": {
                "type": "string",
                "description": "Friendly message describing changes"
            },
            "config": {
                "type": "object",
                "properties": {
                    "fullName": {"type": "string"},
                    "role": {"type": "string"},
                    "bio": {"type": "string"},
                    "skills": {
                        "type": "array",
                        "items": {"type": "string"}
                    },
                    "projects": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "title": {"type": "string"},
                                "description": {"type": "string"},
                                "technologies": {
                                    "type": "array",
                                    "items": {"type": "string"}
                                },
                                "imageUrl": {"type": "string"},
                                "link": {"type": "string"}
                            },
                            "required": ["title", "description", "technologies"]
                        }
                    },
                    "socials": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "platform": {
                                    "type": "string",
                                    "enum": ["GitHub", "LinkedIn", "Twitter", "Email", "Other"]
                                },
                                "url": {"type": "string"}
                            },
                            "required": ["platform", "url"]
                        }
                    },
                    "style": {
                        "type": "object",
                        "properties": {
                            "layout": {
                                "type": "string",
                                "enum": ["minimal", "modern", "bold"]
                            },
                            "fontHeading": {"type": "string"},
                            "fontBody": {"type": "string"},
                            "colors": {
                                "type": "object",
                                "properties": {
                                    "primary": {"type": "string"},
                                    "secondary": {"type": "string"},
                                    "background": {"type": "string"},
                                    "text": {"type": "string"},
                                    "cardBackground": {"type": "string"}
                                },
                                "required": ["primary", "background", "text", "cardBackground"]
                            }
                        },
                        "required": ["layout", "colors"]
                    }
                },
                "required": ["fullName", "role", "bio", "skills", "projects", "socials", "style"]
            }
        },
        "required": ["reply", "config"]
    }

    SYSTEM_INSTRUCTION = """You are Bolt (Portfolio Edition), an expert full-stack developer and designer.

<thinking_process>
  1.  **Analyze**: deeply understand the user's request and resume data.
  2.  **Plan**: determine the best architectural and design approach.
  3.  **Design**: create a cohesive visual identity (typography, colors, spacing).
  4.  **Structure**: define the data model strictly according to the schema.
</thinking_process>

<design_excellence>
  **Visual Identity:**
  - **Typography**: Use a premium hierarchy. Headings (2.5rem-4rem) for impact, readable body text (1rem-1.125rem).
  - **Spacing**: Adhere to an 8pt grid system for consistent rhythm.
  - **Colors**: Ensure WCAG AA accessibility. Use semantic color naming (primary, secondary, accent).
  - **Microbranding**: Suggest unique icons or subtle brand elements.

  **Style Variations:**
  - **minimal**: Clean, monochromatic, negative space, simple sans-serifs (Inter, Geist).
  - **modern**: Glassmorphism, subtle gradients, bento-grid layouts, dark mode default.
  - **bold**: Brutalist influence, large typography, high contrast, sharp borders.
</design_excellence>

<content_guidelines>
  - **Bio**: Professional, value-driven, and concise. No fluff.
  - **Projects**: Action-oriented descriptions (STAR method). Real-world tech stacks.
  - **Skills**: Categorized logically (Frontend, Backend, DevOps).
</content_guidelines>

<generation_rules>
  - Output MUST be valid JSON matching the schema.
  - No markdown formatting around the JSON.
  - The 'reply' field must explain the *why* behind the design choices.
</generation_rules>
"""

    IMPORT_INSTRUCTION = """You are a data extraction expert.
The user uploaded content to import into their portfolio builder.
Content could be:
1. Valid PortfolioConfig JSON (restore exactly)
2. React component file previously generated (reverse engineer the data)
3. Resume or plain text (extract and structure)

Map this into the PortfolioConfig JSON schema.

RULES:
- If JSON, return structure-compliant
- If React Code, extract variables (fullName, role, skills, projects array) back to JSON
- If Resume/Text, intelligently summarize into the schema
- Always provide valid style with default if missing
- Return friendly reply describing what was imported"""

    def __init__(self):
        """Initialize AI clients"""
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        self.openai_api_key = os.getenv("OPENAI_API_KEY")

        if self.gemini_api_key:
            genai.configure(api_key=self.gemini_api_key)

        self.openai_client = (
            AsyncOpenAI(api_key=self.openai_api_key)
            if self.openai_api_key
            else None
        )

    async def generate_config(
        self,
        prompt: str,
        current_config: Optional[Dict] = None,
        resume_data: Optional[Dict] = None,
    ) -> Tuple[Dict, str]:
        """
        Generate portfolio configuration with Chain of Thought planning.
        """
        try:
            # Step 1: Plan
            print("🤔 Planning generation...")
            plan = await self._plan_generation(prompt, resume_data)
            print(f"📋 Plan:\n{plan}")

            # Step 2: Generate Config
            context = f"""User Request: {prompt}

Resume Data:
{json.dumps(resume_data, indent=2) if resume_data else "None"}

Implementation Plan:
{plan}

Current Configuration (if any):
{json.dumps(current_config, indent=2) if current_config else "None"}
"""

            # Try Gemini first
            if self.gemini_api_key:
                print("📍 Using Gemini 2.5 Flash for portfolio generation...")
                return await self._generate_with_gemini(context)

            # Fallback to OpenAI
            if self.openai_client:
                print("⚠️ Gemini unavailable, using OpenAI GPT-4o...")
                return await self._generate_with_openai(context)

            raise ValueError("No AI API keys configured (GEMINI_API_KEY or OPENAI_API_KEY)")

        except Exception as e:
            print(f"❌ Generation error: {str(e)}")
            raise

    async def _plan_generation(self, user_prompt: str, resume_data: Optional[Dict]) -> str:
        """Generate implementation plan before creating portfolio"""
        
        planning_prompt = f"""Analyze this request and create a brief plan:
User Request: {user_prompt}
Resume Data: {json.dumps(resume_data, indent=2) if resume_data else "None"}

Provide a 2-4 line plan covering:
1. Key components needed
2. Visual design approach
3. Technical architecture
4. Potential challenges
"""
        try:
            if self.gemini_api_key:
                model = genai.GenerativeModel("gemini-2.5-flash")
                response = await asyncio.to_thread(
                    model.generate_content,
                    planning_prompt
                )
                return response.text
            elif self.openai_client:
                response = await self.openai_client.chat.completions.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": planning_prompt}]
                )
                return response.choices[0].message.content
        except Exception as e:
            print(f"⚠️ Planning failed: {e}")
            return "Proceed with standard modern portfolio generation."
        
        return "Proceed with standard generation."

    async def _generate_with_gemini(self, context: str) -> Tuple[Dict, str]:
        """Generate using Gemini 2.5 Flash"""
        try:
            model = genai.GenerativeModel("gemini-2.5-flash")

            response = await asyncio.to_thread(
                model.generate_content,
                contents=[
                    {
                        "role": "user",
                        "parts": [{"text": context}],
                    }
                ],
                generation_config={
                    "temperature": 0.7,
                    "response_mime_type": "application/json",
                    "response_schema": self.PORTFOLIO_SCHEMA,
                },
                system_instruction=self.SYSTEM_INSTRUCTION,
            )

            response_text = response.text
            if not response_text:
                raise ValueError("Empty response from Gemini")

            data = json.loads(response_text)
            return data.get("config", {}), data.get("reply", "Portfolio generated!")

        except Exception as e:
            print(f"Gemini error: {str(e)}")
            raise

    async def _generate_with_openai(self, context: str) -> Tuple[Dict, str]:
        """Fallback: Generate using OpenAI GPT-4o"""
        if not self.openai_client:
            raise ValueError("OpenAI client not initialized")

        try:
            response = await self.openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": self.SYSTEM_INSTRUCTION},
                    {"role": "user", "content": context},
                ],
                response_format={"type": "json_schema", "json_schema": {
                    "name": "PortfolioConfig",
                    "schema": self.PORTFOLIO_SCHEMA
                }},
                temperature=0.7,
            )

            response_text = response.choices[0].message.content
            if not response_text:
                raise ValueError("Empty response from OpenAI")

            data = json.loads(response_text)
            return data.get("config", {}), data.get("reply", "Portfolio generated!")

        except Exception as e:
            print(f"OpenAI error: {str(e)}")
            raise

    async def refine_config(
        self,
        current_config: Dict,
        refinement_prompt: str,
    ) -> Tuple[Dict, str]:
        """
        Refine existing portfolio configuration.
        """
        context = f"""Current Configuration:
{json.dumps(current_config, indent=2)}

User Refinement Request: {refinement_prompt}

Please update the configuration based on the user's request.
Keep unchanged properties if not mentioned.
Return the complete updated configuration."""

        return await self.generate_config(context, current_config)

    async def import_config(self, file_content: str) -> Tuple[Dict, str]:
        """
        Import portfolio configuration from file content.
        """
        context = f"Import this content into a PortfolioConfig:\n\n{file_content}"

        try:
            if self.gemini_api_key:
                model = genai.GenerativeModel("gemini-2.5-flash")

                response = await asyncio.to_thread(
                    model.generate_content,
                    contents=[
                        {
                            "role": "user",
                            "parts": [{"text": context}],
                        }
                    ],
                    generation_config={
                        "temperature": 0.5,
                        "response_mime_type": "application/json",
                        "response_schema": self.PORTFOLIO_SCHEMA,
                    },
                    system_instruction=self.IMPORT_INSTRUCTION,
                )

                response_text = response.text
                data = json.loads(response_text)
                return data.get("config", {}), data.get("reply", "Configuration imported!")

            elif self.openai_client:
                response = await self.openai_client.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": self.IMPORT_INSTRUCTION},
                        {"role": "user", "content": context},
                    ],
                    response_format={"type": "json_schema", "json_schema": {
                        "name": "PortfolioConfig",
                        "schema": self.PORTFOLIO_SCHEMA
                    }},
                    temperature=0.5,
                )

                response_text = response.choices[0].message.content
                data = json.loads(response_text)
                return data.get("config", {}), data.get("reply", "Configuration imported!")

            else:
                raise ValueError("No AI API keys configured")

        except Exception as e:
            print(f"Import error: {str(e)}")
            raise


def get_inline_social_icon(platform: str) -> str:
    """
    Get inline SVG icon for social platform.
    
    Args:
        platform: Platform name (GitHub, LinkedIn, Twitter, Email, etc)
        
    Returns:
        SVG string with icon
    """
    icons = {
        "GitHub": """<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0-2-1.5-3-1.5-3-1.5-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/></svg>""",
        "LinkedIn": """<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.225 0z"/></svg>""",
        "Twitter": """<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M23.953 4.57a10 10 0 002.856-9.86 10.02 10.02 0 01-2.857.856 4.958 4.958 0 00-8.618 4.53 14.07 14.07 0 01-10.17-5.14 4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>""",
        "Email": """<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>""",
        "Portfolio": """<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>""",
        "Other": """<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/></svg>""",
    }

    return icons.get(platform, icons["Other"])
