"""
React Portfolio Code Generator

Converts PortfolioConfig JSON to React/Next.js component code using AI.
"""

import os
import json
import asyncio
from typing import Dict, List, Optional
from dotenv import load_dotenv
import google.generativeai as genai
from openai import AsyncOpenAI

load_dotenv()


class ReactCodeGenerator:
    """Generate React portfolio components from PortfolioConfig using AI"""

    def __init__(self):
        """Initialize AI clients"""
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        self.openai_api_key = os.getenv("OPENAI_API_KEY")

        if self.gemini_api_key:
            genai.configure(api_key=self.gemini_api_key)

        self.openai_client = (
            AsyncOpenAI(api_key=self.openai_api_key)
            if self.openai_api_key
            else None
        )

    async def generate_nextjs_files(self, config: Dict) -> Dict[str, str]:
        """
        Generate complete Next.js project files from PortfolioConfig using AI.
        
        Args:
            config: Portfolio configuration
            
        Returns:
            Dictionary of file paths to file contents
        """
        print("🤖 Generating Next.js project with AI...")
        
        try:
            # Generate project structure and content
            files = await self._generate_complete_project_with_ai(config)
            
            # Validate and fix missing files
            files = await self.validate_and_complete_project(files, config)
            
            return files
            
        except Exception as e:
            print(f"❌ AI Code Generation failed: {e}")
            # Fallback to template generation if AI fails (legacy method could be kept as backup)
            raise e

    async def _generate_complete_project_with_ai(self, config: Dict) -> Dict[str, str]:
        """Generate complete Next.js 15 project using AI"""
        
        system_prompt = """You are an expert React/Next.js developer specializing in high-performance portfolios.
        
<system_constraints>
  - You must generate a COMPLETE Next.js 15 App Router project.
  - Use Tailwind CSS for styling.
  - Use Framer Motion for animations.
  - Use Lucide React for icons.
  - Ensure mobile responsiveness.
  - Output must be a valid JSON object where keys are file paths and values are file contents.
</system_constraints>

<file_requirements>
  Generate the following files:
  - package.json (include next, react, react-dom, tailwindcss, framer-motion, lucide-react, clsx, tailwind-merge)
  - tsconfig.json
  - tailwind.config.js (extend theme with portfolio colors)
  - next.config.js
  - app/layout.tsx (Root layout with metadata)
  - app/page.tsx (Main landing page)
  - app/globals.css (Tailwind directives + custom styles)
  - components/Hero.tsx
  - components/About.tsx
  - components/Projects.tsx
  - components/Skills.tsx
  - components/Contact.tsx
  - components/ui/Section.tsx (Wrapper component)
  - lib/utils.ts (cn helper)
</file_requirements>

<code_standards>
  - Use TypeScript interfaces for all props.
  - Use 'use client' directive where necessary (animations, hooks).
  - Implement smooth scrolling.
  - Ensure high accessibility (aria-labels, semantic HTML).
  - NO placeholders or "rest of code" comments. Write FULL code.
</code_standards>
"""

        user_prompt = f"""Generate a portfolio project based on this configuration:
{json.dumps(config, indent=2)}

Return a JSON object containing all the file paths and their complete contents.
"""

        try:
            if self.gemini_api_key:
                print("📍 Using Gemini for code generation...")
                model = genai.GenerativeModel("gemini-2.5-flash")
                response = await asyncio.to_thread(
                    model.generate_content,
                    contents=[
                        {"role": "user", "parts": [{"text": system_prompt + "\n\n" + user_prompt}]}
                    ],
                    generation_config={
                        "temperature": 0.2,
                        "response_mime_type": "application/json"
                    }
                )
                return json.loads(response.text)

            elif self.openai_client:
                print("📍 Using OpenAI for code generation...")
                response = await self.openai_client.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    response_format={"type": "json_object"},
                    temperature=0.2
                )
                return json.loads(response.choices[0].message.content)
            
            raise ValueError("No AI API keys configured")

        except Exception as e:
            print(f"❌ Generation error: {str(e)}")
            raise

    async def validate_and_complete_project(self, files: Dict[str, str], config: Dict) -> Dict[str, str]:
        """Ensure project has all required files"""
        
        required_files = [
            "package.json", 
            "tsconfig.json", 
            "tailwind.config.js",
            "app/layout.tsx", 
            "app/page.tsx", 
            "app/globals.css"
        ]
        
        missing_files = [f for f in required_files if f not in files]
        
        if missing_files:
            print(f"⚠️ Missing files: {missing_files}. Attempting to fix...")
            # Simple fallback for critical files if AI missed them (simplified for now)
            # In a full implementation, we would call the AI again to generate missing files
            pass
            
        return files

    @staticmethod
    def get_social_icon_svg(platform: str) -> str:
        """Legacy helper - kept for backward compatibility if needed"""
        return ""
