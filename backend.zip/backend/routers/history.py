from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from database import get_db
from models import Project, User, Session
from services.auth import auth_service
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime
import uuid

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

async def get_current_user(token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)):
    payload = auth_service.verify_token(token)
    if not payload or payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user_id = payload.get("sub")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    return user

class ProjectResponse(BaseModel):
    id: str
    name: str
    stack: str
    created_at: datetime
    updatedAt: datetime
    status: str = "draft"
    description: str = ""
    framework: str = ""
    theme: str = "default"
    views: int = 0
    thumbnail: Optional[str] = None
    deploymentUrl: Optional[str] = None
    url: Optional[str] = None
    
    class Config:
        from_attributes = True

class HistoryResponse(BaseModel):
    portfolios: List[ProjectResponse]

@router.get("/", response_model=HistoryResponse)
async def get_user_history(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get list of generated portfolios for the current user"""
    result = await db.execute(
        select(Project)
        .where(Project.user_id == current_user.id)
        .order_by(desc(Project.created_at))
    )
    projects = result.scalars().all()
    
    portfolios = [
        ProjectResponse(
            id=p.id,
            name=p.name or "Untitled Portfolio",
            stack=p.stack or "react",
            created_at=p.created_at,
            updatedAt=p.updated_at,
            status="draft",
            description="",
            framework=p.stack or "react",
            theme="default",
            views=0,
            customization=p.customization
        )
        for p in projects
    ]
    
    return HistoryResponse(portfolios=portfolios)

@router.get("/debug/sessions")
async def debug_sessions(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Debug endpoint: List all sessions for current user"""
    result = await db.execute(
        select(Session)
        .where(Session.user_id == current_user.id)
        .order_by(desc(Session.created_at))
    )
    sessions = result.scalars().all()
    
    return {
        "user_id": current_user.id,
        "user_email": current_user.email,
        "session_count": len(sessions),
        "sessions": [
            {
                "id": s.id,
                "resume_filename": s.resume_filename,
                "created_at": s.created_at.isoformat() if s.created_at else None,
                "user_prompt": s.user_prompt[:100] if s.user_prompt else None
            }
            for s in sessions
        ]
    }

@router.delete("/{project_id}")
async def delete_project(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Delete a project"""
    result = await db.execute(
        select(Project)
        .where(Project.id == project_id)
        .where(Project.user_id == current_user.id)
    )
    project = result.scalar_one_or_none()
    
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    await db.delete(project)
    await db.commit()
    
    return {"message": "Project deleted successfully"}

@router.post("/{project_id}/duplicate")
async def duplicate_project(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Duplicate a project"""
    result = await db.execute(
        select(Project)
        .where(Project.id == project_id)
        .where(Project.user_id == current_user.id)
    )
    project = result.scalar_one_or_none()
    
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Create a new project as a duplicate
    new_project = Project(
        id=str(uuid.uuid4()),
        user_id=current_user.id,
        session_id=project.session_id,
        name=f"{project.name or 'Untitled Portfolio'} (Copy)",
        stack=project.stack,
        files=project.files,
        customization=project.customization
    )
    
    db.add(new_project)
    await db.commit()
    await db.refresh(new_project)
    
    return ProjectResponse(
        id=new_project.id,
        name=new_project.name,
        stack=new_project.stack,
        created_at=new_project.created_at,
        updatedAt=new_project.updated_at,
        status="draft",
        description="",
        framework=new_project.stack or "react",
        theme="default",
        views=0
    )
