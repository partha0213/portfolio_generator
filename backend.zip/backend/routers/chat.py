# routers/chat.py - CREATE THIS FILE

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from database import get_db
from models import Session as DBSession, Project, User, ChatHistory
from routers.history import get_current_user
from services.lovable_style_generator import LovableStyleGenerator
from pydantic import BaseModel
from typing import Dict, List, Optional
import uuid

router = APIRouter(prefix="/api/chat", tags=["chat"])

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    session_id: str  # Can be either session_id or project_id
    current_files: Optional[Dict[str, str]] = None

class ChatHistoryResponse(BaseModel):
    id: str
    role: str
    message: str
    created_at: str

@router.post("/{session_or_project_id}/init")
async def init_chat(
    session_or_project_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Initialize chat history with welcome message if it doesn't exist.
    Accepts either session_id or project_id.
    """
    try:
        session_id = session_or_project_id
        
        # Check if this is a project_id instead of session_id
        project_result = await db.execute(
            select(Project)
            .where(
                Project.id == session_or_project_id,
                Project.user_id == current_user.id
            )
        )
        project = project_result.scalars().first()
        
        if project:
            session_id = project.session_id
        
        # Check if welcome message already exists
        existing = await db.execute(
            select(ChatHistory).where(
                ChatHistory.session_id == session_id,
                ChatHistory.role == "assistant",
                ChatHistory.message.contains("Hi! I'm Portfolio.AI")
            )
        )
        
        if not existing.scalars().first():
            # Store initial welcome message
            welcome_msg = ChatHistory(
                id=str(uuid.uuid4()),
                session_id=session_id,
                user_id=current_user.id,
                role="assistant",
                message="Hi! I'm Portfolio.AI. Tell me about yourself, your skills, and the projects you want to showcase, and I'll build a website for you."
            )
            db.add(welcome_msg)
            await db.commit()
            print(f"✅ Welcome message initialized for session {session_id}")
        
        return {
            "success": True,
            "message": "Chat initialized"
        }
    except Exception as e:
        print(f"❌ Error initializing chat: {e}")
        return {
            "success": False,
            "error": str(e)
        }

@router.get("/{session_or_project_id}/history")
async def get_chat_history(
    session_or_project_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Retrieve chat history for a session.
    Accepts either session_id or project_id - will look up session_id from project if needed.
    Always returns chat history (empty list if no messages).
    
    Returns:
    - messages: List of chat messages ordered by creation time
    """
    try:
        session_id = session_or_project_id
        
        print(f"📋 Fetching chat history for: {session_or_project_id} (user: {current_user.id})")
        
        # First, try to find if this is a project_id and get its session_id
        project_result = await db.execute(
            select(Project)
            .where(
                Project.id == session_or_project_id,
                Project.user_id == current_user.id
            )
        )
        project = project_result.scalars().first()
        
        if project:
            print(f"✅ Found project, using session_id: {project.session_id}")
            session_id = project.session_id
        
        # Get all chat history for this session filtered by user (security)
        history_result = await db.execute(
            select(ChatHistory)
            .where(
                ChatHistory.session_id == session_id,
                ChatHistory.user_id == current_user.id
            )
            .order_by(ChatHistory.created_at)
        )
        messages = history_result.scalars().all()
        
        print(f"✅ Found {len(messages)} chat messages for session {session_id}")
        
        return {
            "success": True,
            "messages": [
                {
                    "id": msg.id,
                    "role": msg.role,
                    "message": msg.message,
                    "created_at": msg.created_at.isoformat() if msg.created_at else None
                }
                for msg in messages
            ],
            "count": len(messages)
        }
        
    except Exception as e:
        print(f"⚠️  Error fetching chat history for {session_or_project_id}: {e}")
        import traceback
        traceback.print_exc()
        # Always return success with empty messages on error
        # This ensures chat UI doesn't break
        return {
            "success": True,
            "messages": [],
            "count": 0,
            "error": str(e)
        }

@router.post("/")
async def chat(
    request: ChatRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Chat endpoint for portfolio improvements.
    Used by ChatPanel in editor to modify code files.
    
    Request:
    - messages: Conversation history
    - session_id: Portfolio session ID
    - current_files: Current portfolio files
    
    Returns:
    - response: AI response message
    - file_changes: Dict of modified files (only changed files)
    """
    try:
        print(f"\n💬 CHAT REQUEST - ID: {request.session_id}")
        print(f"👤 User: {current_user.id} ({current_user.email})")
        print(f"📝 Messages: {len(request.messages)}")
        
        session_id = request.session_id
        
        # Check if this is a project_id instead of session_id
        project_result = await db.execute(
            select(Project)
            .where(
                Project.id == request.session_id,
                Project.user_id == current_user.id
            )
        )
        project = project_result.scalars().first()
        
        if project:
            print(f"✅ Found project, using session_id: {project.session_id}")
            session_id = project.session_id
        
        # Get session for context
        result = await db.execute(
            select(DBSession).where(DBSession.id == session_id)
        )
        session = result.scalars().first()
        
        if not session:
            print(f"⚠️ Session not found in DB: {session_id}")
            print(f"⚠️ Proceeding anyway - will still store chat history")
        else:
            print(f"✅ Session found: {session_id} (user_id: {session.user_id})")
        
        resume_data = session.resume_data if session else (request.resume_data or {})
        if isinstance(resume_data, dict) and "data" in resume_data:
            resume_data = resume_data["data"]
        
        # Store user messages in chat history (use resolved session_id)
        for message in request.messages:
            # Check if message already exists in history (avoid duplicates)
            existing = await db.execute(
                select(ChatHistory).where(
                    ChatHistory.session_id == session_id,
                    ChatHistory.role == message.role,
                    ChatHistory.message == message.content
                )
            )
            if not existing.scalars().first():
                chat_msg = ChatHistory(
                    id=str(uuid.uuid4()),
                    session_id=session_id,
                    user_id=current_user.id,
                    role=message.role,
                    message=message.content
                )
                db.add(chat_msg)
                print(f"✅ Stored {message.role} message in session {session_id}")
        
        # Commit chat messages immediately to ensure they're saved
        await db.commit()
        print(f"✅ Chat messages committed to database")
        
        # Get last user message
        last_message = request.messages[-1].content if request.messages else ""
        
        print(f"\n💬 CHAT REQUEST")
        print(f"User: {current_user.email}")
        print(f"Message: {last_message[:100]}...")
        
        # Use Lovable generator for refinement
        generator = LovableStyleGenerator()
        
        refinement_result = await generator.refine_portfolio(
            refinement_request=last_message,
            current_files=request.current_files or {},
            resume_data=resume_data
        )
        
        # Determine assistant response message
        if refinement_result["success"]:
            assistant_response = f"✅ I've updated your portfolio: {last_message}"
            response_message = assistant_response
        else:
            error_msg = refinement_result.get("error", "Unknown error")
            assistant_response = f"I encountered an issue while updating your portfolio: {error_msg}. What would you like to try instead?"
            response_message = assistant_response
        
        # Store assistant response in chat history ALWAYS (success or failure)
        chat_response = ChatHistory(
            id=str(uuid.uuid4()),
            session_id=session_id,
            user_id=current_user.id,
            role="assistant",
            message=assistant_response
        )
        db.add(chat_response)
        await db.commit()
        print(f"✅ Assistant response committed to database: {assistant_response[:80]}...")
        
        # Handle successful refinement
        if refinement_result["success"]:
            # Get project to update
            project_result = await db.execute(
                select(Project)
                .where(Project.session_id == session_id)
                .order_by(Project.created_at.desc())
            )
            project = project_result.scalars().first()
            
            if project:
                project.files = refinement_result["files"]
                await db.commit()
            
            # Calculate file changes (only return changed files)
            file_changes = {}
            if request.current_files:
                for filename, new_content in refinement_result["files"].items():
                    old_content = request.current_files.get(filename, "")
                    if new_content != old_content:
                        file_changes[filename] = new_content
            else:
                file_changes = refinement_result["files"]
            
            print(f"✅ Chat: Updated {len(file_changes)} files")
            
            return {
                "response": response_message,
                "file_changes": file_changes if file_changes else None
            }
        else:
            return {
                "response": response_message,
                "file_changes": None
            }
            
    except Exception as e:
        print(f"❌ Chat error: {e}")
        return {
            "response": f"Sorry, I encountered an error: {str(e)}",
            "file_changes": None
        }
