﻿import { useState, useEffect } from 'react'

function App() {
  const [activeSection, setActiveSection] = useState('home')
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (id) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
      setActiveSection(id)
    }
  }

  return (
    <div className="portfolio">
      {/* Navigation */}
      <nav className={scrolled ? 'nav scrolled' : 'nav'}>
        <div className="nav-container">
          <div className="logo">PARTHASARATHY GANESHPRABU</div>
          <div className="nav-links">
            <a onClick={() => scrollToSection('home')}>Home</a>
            <a onClick={() => scrollToSection('about')}>About</a>
            <a onClick={() => scrollToSection('skills')}>Skills</a>
            <a onClick={() => scrollToSection('projects')}>Projects</a>
            <a onClick={() => scrollToSection('contact')}>Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="hero">
        <div className="hero-content">
          <h1 className="hero-title">Hi, I'm PARTHASARATHY GANESHPRABU</h1>
          <div className="hero-subtitle">
            <span>I'm a </span>
            <span className="typing-text">Full Stack Developer</span>
          </div>
          <p className="hero-description">Motivated to apply my knowledge and skills in a real-world development environment. Eager to gain practical experience and grow professionally through continuous learning. Committed to contributing effectively toward team goals and overall organizational success.</p>
          <div className="hero-buttons">
            <button onClick={() => scrollToSection('contact')} className="btn-primary">
              Hire Me
            </button>
            <button onClick={() => scrollToSection('projects')} className="btn-secondary">
              My Work
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="section">
        <div className="container">
          <h2 className="section-title">About Me</h2>
          <div className="about-content">
            <div className="about-text">
              <h3>Objective</h3>
              <p>Motivated to apply my knowledge and skills in a real-world development environment. Eager to gain practical experience and grow professionally through continuous learning. Committed to contributing effectively toward team goals and overall organizational success.</p>
              
              <h3>Education</h3>
              <div className="education-list">
                <div className="education-item">
                  <h4>M. Kumarasamy College of Engineering</h4>
                  <p>Bachelor of Technology</p>
                  <span className="education-year">2022</span>
                </div>
                <div className="education-item">
                  <h4>Chandy Polytechnic College</h4>
                  <p>Diploma â Marine Engineering</p>
                  <span className="education-year">2023</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="section section-alt">
        <div className="container">
          <h2 className="section-title">Areas of Interest & Skills</h2>
          <div className="skills-grid">
        <div className="skill-category">
          <h3>Languages</h3>
          <div className="skills-list">
            <span className="skill-tag">C++</span>
            <span className="skill-tag">Java</span>
            <span className="skill-tag">Python</span>
            <span className="skill-tag">PHP</span>
            <span className="skill-tag">React</span>
          </div>
        </div>
        <div className="skill-category">
          <h3>Technologies</h3>
          <div className="skills-list">
            <span className="skill-tag">Problem Solving</span>
            <span className="skill-tag">Team Management</span>
            <span className="skill-tag">Decision Making</span>
          </div>
        </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="section">
        <div className="container">
          <h2 className="section-title">Featured Projects</h2>
          <div className="projects-grid">
        <div className="project-card">
          <div className="project-header">
            <h3>Online Social Media Communication Analytics</h3>
            <span className="project-year">(2024)</span>
          </div>
          <p className="project-role">Role: Developer</p>
          <p className="project-desc">This Project analyzes social media interactions, engagement metrics, and sentiments to optimize marketing strategies and enhance brand presence.</p>
          <div className="project-tech">
            
          </div>
          
        </div>
        <div className="project-card">
          <div className="project-header">
            <h3>Early Diagnosis of Pneumonia Using ML</h3>
            <span className="project-year">(2024)</span>
          </div>
          <p className="project-role">Role: Developer</p>
          <p className="project-desc">This Project leveraging machine learning algorithms to predict pneumonia onset, improving diagnostic accuracy and enabling timely medical intervention.</p>
          <div className="project-tech">
            
          </div>
          
        </div>
        <div className="project-card">
          <div className="project-header">
            <h3>Marine Environment Restoration Project</h3>
            <span className="project-year">(2024)</span>
          </div>
          <p className="project-role">Role: Developer</p>
          <p className="project-desc">This Project Developed a web application using React, Express, and MongoDB, deployed on Firebase, to promote marine ecosystem conservation.</p>
          <div className="project-tech">
            React, Express, MongoDB, Firebase
          </div>
          
        </div>
        <div className="project-card">
          <div className="project-header">
            <h3>Green-Farm: AI-Powered Agricultural Marketplace (Ongoing)</h3>
            <span className="project-year">(2024)</span>
          </div>
          <p className="project-role">Role: Developer</p>
          <p className="project-desc">Building a farmer-centric online marketplace that enables farmers to sell their produce directly to buyers. Implementing AI-based crop quality analysis using image recognition and integrating blockchain-secured transactions for payments. The platform supports multiple languages and includes UPI payment integration.</p>
          <div className="project-tech">
            
          </div>
          
        </div>
        <div className="project-card">
          <div className="project-header">
            <h3>Job Portal System</h3>
            <span className="project-year">(2024)</span>
          </div>
          <p className="project-role">Role: Developer</p>
          <p className="project-desc">This project leverages the CodeIgniter MVC framework and Bootstrap to build a responsive job portal that enables users to register, browse job listings, and apply seamlessly. It includes an admin panel for efficient job posting, resume management, and candidate tracking, improving recruitment workflow and user experience.</p>
          <div className="project-tech">
            CodeIgniter, Bootstrap
          </div>
          
        </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="section section-alt">
        <div className="container">
          <h2 className="section-title">Contact Me!</h2>
          <div className="contact-content">
            <p className="contact-email">Email: parthasarathyg693@gmail.com</p>
            <p className="contact-phone">Phone: 7094656709</p>
            <a href="mailto:parthasarathyg693@gmail.com" className="btn-primary">Send Message</a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>Â© 2025 PARTHASARATHY GANESHPRABU | All Rights Reserved</p>
      </footer>
    </div>
  )
}

export default App
